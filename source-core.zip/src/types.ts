export type CharacterStatus =
  | "normal"
  | "ferido"
  | "morrendo"
  | "inconsciente"
  | "morto"
  | "exausto"
  | "sob-efeito"
  | "fora-de-combate";

export interface Vital {
  id: string;
  label: string;
  current: number;
  max: number;
  color: string;
}

export interface CharacterSectionItem {
  id: string;
  name: string;
  description?: string;
  value?: string;
  tags?: string[];
  extra?: Record<string, unknown>;
}

export interface CharacterSection {
  id: string;
  title: string;
  items: CharacterSectionItem[];
}

export interface CharacterSheet {
  id: string;
  customName?: string;
  identity: {
    name: string;
    player?: string;
    origin?: string;
    className?: string;
    path?: string;
    nex?: string;
    level?: string;
    rank?: string;
    organization?: string;
    age?: string;
    description?: string;
  };
  avatarUrl?: string;
  attributes: Record<string, number | string>;
  vitals: Vital[];
  combat: Record<string, string | number | boolean | null>;
  sections: CharacterSection[];
  additional: Record<string, unknown>;
  source: {
    provider: "cris";
    url: string;
    recordId: string;
    importedAt: number;
    refreshedAt: number;
    method: "firestore-best-effort" | "public-html";
  };
  session: {
    status: CharacterStatus;
    vitalOverrides: Record<string, number>;
    note?: string;
  };
}

export interface AppSettings {
  autoRefreshMinutes: 0 | 5 | 15 | 30;
  showAttributes: boolean;
  showInventory: boolean;
  showAbilities: boolean;
  showPhoto: boolean;
  compactMode: boolean;
  animations: boolean;
}

export interface SceneState {
  schemaVersion: 1;
  characters: Record<string, CharacterSheet>;
  settings: AppSettings;
  updatedAt: number;
}

export interface ImportResult {
  character: CharacterSheet;
  warnings: string[];
}

export interface TokenSummary {
  id: string;
  name: string;
  layer: string;
  characterId?: string;
}

export interface CrisImportError extends Error {
  code:
    | "INVALID_URL"
    | "NOT_FOUND"
    | "PRIVATE_OR_FORBIDDEN"
    | "CORS_BLOCKED"
    | "NETWORK"
    | "UNSUPPORTED_PAGE"
    | "UNKNOWN";
  details?: string;
}
