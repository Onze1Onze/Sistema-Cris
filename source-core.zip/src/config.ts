export const EXTENSION_ID = "com.onze1onze.conexao-cris";
export const SCENE_STATE_KEY = `${EXTENSION_ID}/state`;
export const TOKEN_BINDING_KEY = `${EXTENSION_ID}/character`;
export const CONTEXT_MENU_ID = `${EXTENSION_ID}/open-character`;
export const CONTEXT_POPOVER_ID = `${EXTENSION_ID}/token-popover`;
export const FIRESTORE_PROJECT_ID = "cris-ordem-paranormal";
export const FIRESTORE_COLLECTION = "characters";
export const FIRESTORE_SOURCE_REFERENCE =
  "https://github.com/LucasPennacchi/visualizador_de_fichas/blob/main/services/servico-poller/adapters/crisAdapter.js";
export const CRIS_HOSTS = new Set(["crisordemparanormal.com", "www.crisordemparanormal.com"]);
export const MAX_SYNC_STATE_BYTES = 900_000;
export const DEFAULT_SETTINGS = {
  autoRefreshMinutes: 0 as const,
  showAttributes: true,
  showInventory: true,
  showAbilities: true,
  showPhoto: true,
  compactMode: false,
  animations: true,
};

export const STATUS_LABELS: Record<string, string> = {
  normal: "Normal",
  ferido: "Ferido",
  morrendo: "Morrendo",
  inconsciente: "Inconsciente",
  morto: "Morto",
  exausto: "Exausto",
  "sob-efeito": "Sob efeito",
  "fora-de-combate": "Fora de combate",
};
