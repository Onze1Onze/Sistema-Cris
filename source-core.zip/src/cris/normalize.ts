import type {
  CharacterSection,
  CharacterSectionItem,
  CharacterSheet,
  ImportResult,
  Vital,
} from "../types";
import { asNumber, asRecord, asText, safeHttpsUrl } from "../utils/safe";
import type { FirestoreRecord } from "./firestore";

const FIELD_ALIASES = {
  name: ["name", "nome", "characterName", "agentName"],
  player: ["player", "playerName", "ownerName", "jogador"],
  origin: ["origin", "originName", "origem"],
  className: ["className", "class", "classe", "classLabel"],
  path: ["path", "pathName", "trilha", "subclass"],
  nex: ["nex", "nivelExposicao", "exposure", "nexValue"],
  level: ["level", "nivel", "characterLevel"],
  rank: ["rank", "patent", "patente", "agentRank"],
  organization: ["organization", "group", "faction", "organizacao", "grupo"],
  age: ["age", "idade"],
  description: ["description", "descricao", "history", "background", "appearance"],
  avatar: ["sheetPictureURL", "avatarUrl", "imageUrl", "portrait", "photo", "picture", "foto"],
} as const;

function keyOf(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function getValue(record: Record<string, unknown>, aliases: readonly string[]): unknown {
  const wanted = new Set(aliases.map(keyOf));
  const found = Object.entries(record).find(([key]) => wanted.has(keyOf(key)));
  return found?.[1];
}

function getText(record: Record<string, unknown>, aliases: readonly string[]): string | undefined {
  return asText(getValue(record, aliases));
}

function getNumber(record: Record<string, unknown>, aliases: readonly string[]): number | undefined {
  return asNumber(getValue(record, aliases));
}

function readVital(
  record: Record<string, unknown>,
  id: string,
  label: string,
  currentAliases: readonly string[],
  maxAliases: readonly string[],
  color: string,
): Vital | undefined {
  const current = getNumber(record, currentAliases);
  const max = getNumber(record, maxAliases);
  if (current === undefined && max === undefined) return undefined;
  return {
    id,
    label,
    current: Math.max(0, current ?? max ?? 0),
    max: Math.max(0, max ?? current ?? 0),
    color,
  };
}

function normalizeListItem(value: unknown, index: number): CharacterSectionItem {
  const record = asRecord(value);
  const name = getText(record, ["name", "nome", "label", "title", "titulo", "itemName", "ritualName"]) ??
    (typeof value === "string" ? value : `Registro ${index + 1}`);
  const description = getText(record, ["description", "descricao", "effect", "efeito", "text", "texto", "details"]);
  const rawValue = getValue(record, ["value", "bonus", "trainingDegree", "rank", "degree", "valor"]);
  const tagsValue = getValue(record, ["attribute", "atributo", "type", "tipo", "category", "categoria", "trained"]);
  const tags = Array.isArray(tagsValue)
    ? tagsValue.map(asText).filter((item): item is string => Boolean(item))
    : (asText(tagsValue) ? [asText(tagsValue)!] : []);
  const known = new Set([
    "name", "nome", "label", "title", "titulo", "itemName", "ritualName",
    "description", "descricao", "effect", "efeito", "text", "texto", "details",
    "value", "bonus", "trainingDegree", "rank", "degree", "valor",
    "attribute", "atributo", "type", "tipo", "category", "categoria", "trained",
  ].map(keyOf));
  const extra = Object.fromEntries(Object.entries(record).filter(([key]) => !known.has(keyOf(key))));
  return {
    id: `${index}-${keyOf(name).slice(0, 24)}`,
    name,
    ...(description ? { description } : {}),
    ...(rawValue !== undefined ? { value: String(rawValue) } : {}),
    ...(tags.length ? { tags } : {}),
    ...(Object.keys(extra).length ? { extra } : {}),
  };
}

function asList(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object") {
    const record = asRecord(value);
    const values = record.values ?? record.items ?? record.entries;
    return Array.isArray(values) ? values : Object.values(record);
  }
  if (typeof value === "string" && value.trim()) return value.split(/[\n;,]+/).map((item) => item.trim()).filter(Boolean);
  return [];
}

function section(
  record: Record<string, unknown>,
  id: string,
  title: string,
  aliases: readonly string[],
): CharacterSection | undefined {
  const value = getValue(record, aliases);
  const items = asList(value).map(normalizeListItem);
  if (items.length === 0) return undefined;
  return { id, title, items };
}

const ROOT_KNOWN_FIELDS = new Set(
  [
    ...Object.values(FIELD_ALIASES).flat(),
    "attributes", "atributos", "currentPv", "maxPv", "currentHp", "maxHp", "pvAtual", "pvMaximo",
    "currentPe", "maxPe", "currentSan", "maxSan", "currentPd", "maxPd", "currentDt", "maxDt",
    "evade", "defense", "defence", "block", "movement", "initiative", "resistances", "currentLoad", "maxLoad",
    "skills", "pericias", "inventory", "inventario", "rituals", "rituais", "powers", "poderes",
    "abilities", "habilidades", "features", "weapons", "armas", "equipment", "equipamentos", "armor", "protecao",
    "deathMode", "madnessMode", "isPdOn", "isSobrevivendoAoHorror",
  ].map(keyOf),
);

export function normalizeFirestoreCharacter(
  characterId: string,
  sourceUrl: string,
  rawInput: FirestoreRecord,
  importedAt = Date.now(),
): ImportResult {
  const raw = asRecord(rawInput);
  const attributesRaw = asRecord(getValue(raw, ["attributes", "atributos", "stats"]));
  const attributeAliases: Record<string, readonly string[]> = {
    AGI: ["dex", "dexterity", "agility", "agi", "agilidade"],
    FOR: ["str", "strength", "for", "forca", "força"],
    INT: ["int", "intelligence", "intelecto"],
    PRE: ["pre", "presence", "presenca", "presença"],
    VIG: ["con", "constitution", "vigor", "vig"],
  };
  const attributes: Record<string, number | string> = {};
  for (const [label, aliases] of Object.entries(attributeAliases)) {
    const value = getValue(attributesRaw, aliases);
    if (value !== undefined && value !== null && value !== "") {
      attributes[label] = asNumber(value) ?? asText(value) ?? String(value);
    }
  }

  const vitals = [
    readVital(raw, "hp", "PV", ["currentPv", "currentHp", "pvAtual", "hp", "vidaAtual"], ["maxPv", "maxHp", "pvMaximo", "hpMax", "vidaMaxima"], "#c83a43"),
    readVital(raw, "pe", "PE", ["currentPe", "peAtual", "effortCurrent"], ["maxPe", "peMaximo", "effortMax"], "#c89c46"),
    readVital(raw, "san", "SAN", ["currentSan", "sanAtual", "sanityCurrent"], ["maxSan", "sanMaximo", "sanityMax"], "#a7a0b8"),
    readVital(raw, "dt", "DT", ["currentPd", "currentDt", "pdAtual", "dtAtual"], ["maxPd", "maxDt", "pdMaximo", "dtMaximo"], "#8a6ac8"),
  ].filter((item): item is Vital => Boolean(item));

  const combat: Record<string, string | number | boolean | null> = {};
  const combatFields: Array<[string, readonly string[]]> = [
    ["Defesa", ["defense", "defence", "evade", "defesa"]],
    ["Esquiva", ["dodge", "esquiva"]],
    ["Bloqueio", ["block", "bloqueio"]],
    ["Iniciativa", ["initiative", "iniciativa"]],
    ["Deslocamento", ["movement", "speed", "deslocamento"]],
    ["Carga atual", ["currentLoad", "cargaAtual"]],
    ["Carga máxima", ["maxLoad", "cargaMaxima"]],
    ["Resistências", ["resistances", "resistencia", "resistencias"]],
  ];
  for (const [label, aliases] of combatFields) {
    const value = getValue(raw, aliases);
    if (value !== undefined && value !== null && value !== "") {
      combat[label] = asNumber(value) ?? asText(value) ?? (typeof value === "boolean" ? value : String(value));
    }
  }

  const sections = [
    section(raw, "skills", "Perícias", ["skills", "pericias", "perícias"]),
    section(raw, "powers", "Poderes", ["powers", "poderes"]),
    section(raw, "abilities", "Habilidades", ["abilities", "habilidades", "features"]),
    section(raw, "rituals", "Rituais", ["rituals", "rituais"]),
    section(raw, "inventory", "Inventário", ["inventory", "inventario", "inventário"]),
    section(raw, "weapons", "Armas", ["weapons", "armas", "attacks", "ataques"]),
    section(raw, "equipment", "Equipamentos", ["equipment", "equipamentos", "armor", "protecao", "proteção"]),
  ].filter((item): item is CharacterSection => Boolean(item));

  const additional = Object.fromEntries(
    Object.entries(raw).filter(([key]) => !ROOT_KNOWN_FIELDS.has(keyOf(key))),
  );
  const imageValue = getText(raw, FIELD_ALIASES.avatar);
  const avatarUrl = safeHttpsUrl(imageValue);
  const name = getText(raw, FIELD_ALIASES.name) ?? "Agente sem identificação";
  const identity = {
    name,
    ...(getText(raw, FIELD_ALIASES.player) ? { player: getText(raw, FIELD_ALIASES.player) } : {}),
    ...(getText(raw, FIELD_ALIASES.origin) ? { origin: getText(raw, FIELD_ALIASES.origin) } : {}),
    ...(getText(raw, FIELD_ALIASES.className) ? { className: getText(raw, FIELD_ALIASES.className) } : {}),
    ...(getText(raw, FIELD_ALIASES.path) ? { path: getText(raw, FIELD_ALIASES.path) } : {}),
    ...(getText(raw, FIELD_ALIASES.nex) ? { nex: getText(raw, FIELD_ALIASES.nex) } : {}),
    ...(getText(raw, FIELD_ALIASES.level) ? { level: getText(raw, FIELD_ALIASES.level) } : {}),
    ...(getText(raw, FIELD_ALIASES.rank) ? { rank: getText(raw, FIELD_ALIASES.rank) } : {}),
    ...(getText(raw, FIELD_ALIASES.organization) ? { organization: getText(raw, FIELD_ALIASES.organization) } : {}),
    ...(getText(raw, FIELD_ALIASES.age) ? { age: getText(raw, FIELD_ALIASES.age) } : {}),
    ...(getText(raw, FIELD_ALIASES.description) ? { description: getText(raw, FIELD_ALIASES.description) } : {}),
  };

  const warnings: string[] = [];
  if (!avatarUrl) warnings.push("A fonte não forneceu um retrato HTTPS reconhecível.");
  if (!vitals.length) warnings.push("Não foram encontrados valores de PV, PE, SAN ou DT.");
  if (!Object.keys(attributes).length) warnings.push("Não foram encontrados atributos reconhecíveis.");
  if (Object.keys(additional).length) warnings.push("Campos não mapeados foram preservados em Informações adicionais.");

  return {
    character: {
      id: `cris-${characterId}`,
      identity,
      ...(avatarUrl ? { avatarUrl } : {}),
      attributes,
      vitals,
      combat,
      sections,
      additional,
      source: {
        provider: "cris",
        url: sourceUrl,
        recordId: characterId,
        importedAt,
        refreshedAt: importedAt,
        method: "firestore-best-effort",
      },
      session: { status: "normal", vitalOverrides: {} },
    },
    warnings,
  };
}
