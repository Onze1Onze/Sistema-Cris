import type { CharacterSection, CharacterSheet, ImportResult } from "../types";
import { asRecord, safeHttpsUrl } from "../utils/safe";

function meta(document: Document, selectors: string[]): string | undefined {
  for (const selector of selectors) {
    const value = document.querySelector<HTMLMetaElement>(selector)?.content?.trim();
    if (value) return value;
  }
  return undefined;
}

function cleanTitle(value: string): string {
  return value.replace(/\s*[|—-]\s*C\.?R\.?I\.?S\.?\s*$/i, "").trim();
}

function extractLabelPairs(document: Document): Record<string, string> {
  const result: Record<string, string> = {};
  const nodes = document.querySelectorAll<HTMLElement>("dt, th, label, [data-label]");
  for (const node of nodes) {
    const label = (node.textContent ?? node.getAttribute("data-label") ?? "").trim().replace(/[:：]$/, "");
    if (!label || label.length > 64) continue;
    const row = node.closest("tr");
    const sibling = node.nextElementSibling;
    const value = row
      ? row.querySelector("td:nth-child(2)")?.textContent
      : sibling?.textContent ?? node.parentElement?.textContent?.replace(label, "");
    const normalized = value?.trim();
    if (normalized && normalized.length <= 500 && normalized !== label) result[label] = normalized;
  }
  return result;
}

function extractSections(document: Document): CharacterSection[] {
  const sections: CharacterSection[] = [];
  const headings = document.querySelectorAll<HTMLElement>("h1, h2, h3, h4, [role='heading']");
  headings.forEach((heading, index) => {
    const title = (heading.textContent ?? "").trim();
    if (!title || title.length > 80) return;
    const container = heading.parentElement;
    if (!container) return;
    const candidates = Array.from(container.querySelectorAll("li, [role='listitem'], article, .card"));
    const items = candidates.slice(0, 100).map((node, itemIndex) => {
      const text = (node.textContent ?? "").trim();
      return {
        id: `${index}-${itemIndex}`,
        name: text.slice(0, 120) || `Registro ${itemIndex + 1}`,
        ...(text.length > 120 ? { description: text.slice(120, 1800) } : {}),
      };
    });
    if (items.length) sections.push({ id: `html-${index}`, title, items });
  });
  return sections;
}

function findStructuredData(document: Document): Record<string, unknown> {
  const scripts = document.querySelectorAll<HTMLScriptElement>(
    'script[type="application/ld+json"], script[type="application/json"], script#__NEXT_DATA__',
  );
  const collected: Record<string, unknown> = {};
  for (const script of scripts) {
    try {
      const parsed: unknown = JSON.parse(script.textContent ?? "null");
      const record = asRecord(parsed);
      Object.assign(collected, record);
    } catch {
      // JSON embutido inválido não impede a leitura de metadados públicos.
    }
  }
  return collected;
}

export function parsePublicCharacterHtml(
  html: string,
  sourceUrl: string,
  characterId: string,
  importedAt = Date.now(),
): ImportResult {
  const document = new DOMParser().parseFromString(html, "text/html");
  const structured = findStructuredData(document);
  const title = cleanTitle(
    meta(document, ['meta[property="og:title"]', 'meta[name="twitter:title"]']) ??
      document.querySelector("h1")?.textContent?.trim() ?? document.title,
  );
  const description = meta(document, ['meta[property="og:description"]', 'meta[name="description"]']);
  const image = safeHttpsUrl(
    meta(document, ['meta[property="og:image"]', 'meta[name="twitter:image"]']) ??
      document.querySelector<HTMLImageElement>('img[itemprop="image"], img[data-testid*="avatar"], img[class*="avatar"]')?.src,
  );
  const pairs = extractLabelPairs(document);
  const sections = extractSections(document);
  const textContent = (document.body?.innerText ?? document.body?.textContent ?? "").trim().slice(0, 12_000);

  const additional: Record<string, unknown> = {
    "Campos extraídos por rótulo": pairs,
    "Dados estruturados da página": structured,
    ...(textContent ? { "Texto público da página": textContent } : {}),
  };
  const name = title || "Ficha pública do CRIS";
  const character: CharacterSheet = {
    id: `cris-${characterId}`,
    identity: {
      name,
      ...(description ? { description } : {}),
    },
    ...(image ? { avatarUrl: image } : {}),
    attributes: {},
    vitals: [],
    combat: {},
    sections,
    additional,
    source: {
      provider: "cris",
      url: sourceUrl,
      recordId: characterId,
      importedAt,
      refreshedAt: importedAt,
      method: "public-html",
    },
    session: { status: "normal", vitalOverrides: {} },
  };

  const hasData = Boolean(title || description || image || Object.keys(pairs).length || sections.length);
  if (!hasData || /faça login|você precisa estar logado|ficha privada|não encontrado/i.test(textContent)) {
    throw Object.assign(new Error("A página não expôs dados suficientes para montar uma ficha pública."), {
      code: "UNSUPPORTED_PAGE",
    });
  }

  return {
    character,
    warnings: [
      "A página não expôs o registro completo; foi criada uma ficha parcial com metadados e campos públicos encontrados.",
      "Campos não estruturados foram preservados em Informações adicionais.",
    ],
  };
}
