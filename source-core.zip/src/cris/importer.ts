import type { ImportResult, CrisImportError } from "../types";
import { parseCrisUrl } from "./url";
import { fetchPublicFirestoreCharacter } from "./firestore";
import { normalizeFirestoreCharacter } from "./normalize";
import { parsePublicCharacterHtml } from "./htmlParser";

function makeError(code: CrisImportError["code"], message: string, details?: string): CrisImportError {
  return Object.assign(new Error(message), { code, details });
}

async function fetchPublicHtml(url: string, timeoutMs = 10_000): Promise<string> {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: "GET",
      mode: "cors",
      credentials: "omit",
      redirect: "follow",
      cache: "no-store",
      headers: { Accept: "text/html,application/xhtml+xml" },
      signal: controller.signal,
    });
    if (response.status === 401 || response.status === 403) {
      throw makeError("PRIVATE_OR_FORBIDDEN", "Esta ficha não está disponível publicamente.", `HTTP ${response.status}`);
    }
    if (response.status === 404) {
      throw makeError("NOT_FOUND", "O link não corresponde a uma ficha pública encontrada.");
    }
    if (!response.ok) {
      throw makeError("NETWORK", "O CRIS não respondeu à leitura pública da ficha.", `HTTP ${response.status}`);
    }
    return await response.text();
  } catch (error) {
    if (error instanceof Error && "code" in error) throw error;
    if (error instanceof DOMException && error.name === "AbortError") {
      throw makeError("NETWORK", "A leitura da página do CRIS excedeu o tempo limite.");
    }
    if (error instanceof TypeError) {
      throw makeError("CORS_BLOCKED", "O navegador bloqueou a leitura da página pública do CRIS (CORS ou conexão indisponível).", error.message);
    }
    throw makeError("UNKNOWN", "Não foi possível ler a página pública do CRIS.", String(error));
  } finally {
    window.clearTimeout(timeout);
  }
}

export async function importCrisCharacter(inputUrl: string): Promise<ImportResult> {
  const parsed = parseCrisUrl(inputUrl);
  const firestoreError: unknown[] = [];

  try {
    const raw = await fetchPublicFirestoreCharacter(parsed.characterId);
    return normalizeFirestoreCharacter(parsed.characterId, parsed.url, raw);
  } catch (error) {
    firestoreError.push(error);
  }

  try {
    const html = await fetchPublicHtml(parsed.url);
    return parsePublicCharacterHtml(html, parsed.url, parsed.characterId);
  } catch (htmlError) {
    const first = firestoreError[0] as CrisImportError | undefined;
    const second = htmlError as CrisImportError;

    if (first?.code === "PRIVATE_OR_FORBIDDEN" || second?.code === "PRIVATE_OR_FORBIDDEN") {
      throw makeError(
        "PRIVATE_OR_FORBIDDEN",
        "Não foi possível acessar os dados desta ficha. Confirme que o link é público; a extensão não solicita nem usa credenciais do CRIS.",
        `${first?.message ?? "Firestore indisponível"}; ${second?.message ?? "HTML indisponível"}`,
      );
    }
    if (first?.code === "NOT_FOUND" && second?.code === "NOT_FOUND") {
      throw makeError("NOT_FOUND", "A ficha não foi encontrada. Confira se o link ainda existe.");
    }
    if (first?.code === "CORS_BLOCKED" || second?.code === "CORS_BLOCKED") {
      throw makeError(
        "CORS_BLOCKED",
        "O CRIS ou o navegador bloqueou a leitura direta (CORS). Não foi usado proxy nem contorno de autenticação. A importação automática não está disponível para esta ficha neste ambiente.",
        `${first?.message ?? "Firestore"}; ${second?.message ?? "HTML"}`,
      );
    }
    throw makeError(
      "UNSUPPORTED_PAGE",
      "Não foi possível interpretar a ficha. Ela pode estar privada ou a estrutura pública do CRIS pode ter mudado.",
      `${first instanceof Error ? first.message : String(first)}; ${second instanceof Error ? second.message : String(second)}`,
    );
  }
}
