import { CRIS_HOSTS } from "../config";
import type { CrisImportError } from "../types";

export interface ParsedCrisUrl {
  url: string;
  characterId: string;
}

function importError(code: CrisImportError["code"], message: string): CrisImportError {
  return Object.assign(new Error(message), { code });
}

export function parseCrisUrl(input: string): ParsedCrisUrl {
  let parsed: URL;
  try {
    parsed = new URL(input.trim());
  } catch {
    throw importError("INVALID_URL", "Informe um link válido do C.R.I.S.");
  }

  if (parsed.protocol !== "https:" || !CRIS_HOSTS.has(parsed.hostname.toLowerCase())) {
    throw importError("INVALID_URL", "Use um link HTTPS público de crisordemparanormal.com.");
  }
  if (parsed.username || parsed.password) {
    throw importError("INVALID_URL", "O link não pode conter credenciais.");
  }

  const match = parsed.pathname.match(/^\/agente\/([A-Za-z0-9_-]+)\/?$/i);
  if (!match?.[1]) {
    throw importError(
      "INVALID_URL",
      "O link precisa apontar para uma ficha de agente no formato /agente/ID.",
    );
  }

  parsed.hash = "";
  parsed.search = "";
  return { url: parsed.toString().replace(/\/$/, ""), characterId: match[1] };
}
