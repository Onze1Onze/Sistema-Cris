import { FIRESTORE_COLLECTION, FIRESTORE_PROJECT_ID } from "../config";
import type { CrisImportError } from "../types";
import { asRecord } from "../utils/safe";

export type FirestoreRecord = Record<string, unknown>;

function makeError(
  code: CrisImportError["code"],
  message: string,
  details?: string,
): CrisImportError {
  return Object.assign(new Error(message), { code, details });
}

/**
 * Decodifica os valores tipados do Firestore REST API.
 * Não precisa de SDK Firebase, chave privada, cookie ou sessão do usuário.
 */
export function decodeFirestoreValue(value: unknown): unknown {
  const typed = asRecord(value);
  if ("stringValue" in typed) return typed.stringValue;
  if ("integerValue" in typed) return Number(typed.integerValue);
  if ("doubleValue" in typed) return Number(typed.doubleValue);
  if ("booleanValue" in typed) return typed.booleanValue;
  if ("nullValue" in typed) return null;
  if ("timestampValue" in typed) return typed.timestampValue;
  if ("referenceValue" in typed) return typed.referenceValue;
  if ("bytesValue" in typed) return typed.bytesValue;
  if ("geoPointValue" in typed) return typed.geoPointValue;
  if ("mapValue" in typed) {
    const fields = asRecord(asRecord(typed.mapValue).fields);
    return Object.fromEntries(
      Object.entries(fields).map(([key, nested]) => [key, decodeFirestoreValue(nested)]),
    );
  }
  if ("arrayValue" in typed) {
    const values = asRecord(typed.arrayValue).values;
    return Array.isArray(values) ? values.map(decodeFirestoreValue) : [];
  }
  return value;
}

export function decodeFirestoreDocument(document: unknown): FirestoreRecord {
  const record = asRecord(document);
  const fields = asRecord(record.fields);
  return Object.fromEntries(
    Object.entries(fields).map(([key, value]) => [key, decodeFirestoreValue(value)]),
  );
}

export async function fetchPublicFirestoreCharacter(
  characterId: string,
  timeoutMs = 12_000,
): Promise<FirestoreRecord> {
  // O caminho abaixo foi observado em um adaptador comunitário público; não é uma API
  // oficialmente documentada pelo C.R.I.S. e pode mudar sem aviso.
  const endpoint =
    `https://firestore.googleapis.com/v1/projects/${FIRESTORE_PROJECT_ID}` +
    `/databases/(default)/documents/${FIRESTORE_COLLECTION}/${encodeURIComponent(characterId)}`;
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(endpoint, {
      method: "GET",
      mode: "cors",
      credentials: "omit",
      redirect: "follow",
      cache: "no-store",
      headers: { Accept: "application/json" },
      signal: controller.signal,
    });

    if (response.status === 404) {
      throw makeError("NOT_FOUND", "A ficha não foi encontrada na fonte pública do CRIS.");
    }
    if (response.status === 401 || response.status === 403) {
      throw makeError(
        "PRIVATE_OR_FORBIDDEN",
        "O CRIS não disponibilizou os dados desta ficha publicamente.",
        `HTTP ${response.status}`,
      );
    }
    if (!response.ok) {
      throw makeError(
        "NETWORK",
        "A fonte de dados do CRIS respondeu com erro.",
        `HTTP ${response.status}`,
      );
    }

    const payload: unknown = await response.json();
    const fields = decodeFirestoreDocument(payload);
    if (Object.keys(fields).length === 0) {
      throw makeError("UNSUPPORTED_PAGE", "A resposta não contém campos de personagem reconhecíveis.");
    }
    return fields;
  } catch (error) {
    if (error instanceof Error && "code" in error) throw error;
    if (error instanceof DOMException && error.name === "AbortError") {
      throw makeError("NETWORK", "A consulta ao CRIS excedeu o tempo limite.");
    }
    if (error instanceof TypeError) {
      throw makeError(
        "CORS_BLOCKED",
        "O navegador bloqueou o acesso direto à fonte do CRIS (CORS ou conexão indisponível).",
        error.message,
      );
    }
    throw makeError("UNKNOWN", "Não foi possível interpretar a resposta pública do CRIS.", String(error));
  } finally {
    window.clearTimeout(timeout);
  }
}
