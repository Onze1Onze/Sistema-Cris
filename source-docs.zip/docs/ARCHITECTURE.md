# Arquitetura

## Fronteiras dos módulos

```text
src/
├── main.ts                  Inicialização do painel
├── config.ts                Namespace da extensão e constantes
├── types.ts                 Modelo normalizado e tipos de sessão
├── cris/
│   ├── url.ts               Validação estrita de URL do CRIS
│   ├── firestore.ts         Decodificação REST de documento Firestore
│   ├── normalize.ts         Mapeamento tolerante para o modelo interno
│   ├── htmlParser.ts        Parser alternativo de HTML público
│   └── importer.ts          Orquestração e classificação de erros
├── storage/
│   ├── cache.ts             Cache local IndexedDB/localStorage
│   └── repository.ts        Estado da cena e sincronização via Owlbear
├── owlbear/
│   └── tokens.ts            Context menu, popover e metadados de Token
├── ui/
│   ├── app.ts               Estado da interface e ações
│   └── styles.css           Interface vertical temática
└── utils/
    └── safe.ts              Escape HTML, validação de URL e formatos
```

## Modelo interno

Cada personagem possui:

- `identity`: nome, jogador, origem, classe, trilha, NEX/nível, patente e organização.
- `avatarUrl`: URL HTTPS do retrato, nunca uma imagem embutida no HTML da interface.
- `attributes`, `vitals`, `combat`: dados reconhecidos pelo normalizador.
- `sections`: listas de perícias, habilidades, rituais, armas, equipamentos e inventário.
- `additional`: campos públicos não reconhecidos preservados como objeto genérico.
- `source`: URL, identificador, método e timestamps de importação/atualização.
- `session`: estado e substituições de recursos criados no Owlbear; não são enviados ao CRIS.

## Persistência e sincronização

- `OBR.scene.getMetadata` / `OBR.scene.setMetadata`: biblioteca normalizada compartilhada na cena atual. `onMetadataChange` atualiza os participantes conectados.
- `OBR.scene.items.updateItems`: grava a chave `com.onze1onze.conexao-cris/character` no metadata do Token. A referência é um identificador interno estável da ficha, não depende da posição do Token.
- `IndexedDB`: cópia local de contingência, escopada pelo ID da sala. Se IndexedDB não estiver disponível, usa localStorage.
- `OBR.room` não é usado para guardar documentos completos; a documentação limita o total do metadata da sala a 16 kB.

O metadata da cena não possui limite de tamanho especificado na página de referência consultada. Ainda assim, o projeto aplica um limite interno de 900 kB para evitar gravações desproporcionais. Uma ficha que exceda esse limite permanece em cache local, mas não será sincronizada.

## Permissões

- A extensão consulta `OBR.player.getRole()`.
- `GM`: pode importar, atualizar, remover, vincular Tokens e alterar estado de sessão.
- `PLAYER`: somente leitura do estado compartilhado da cena.
- O menu contextual do Token é registrado via `OBR.contextMenu.create`; abre um popover de ficha por `OBR.popover.open`.

## Estratégia de atualização

- Atualização manual sob demanda.
- Atualização automática desativada por padrão.
- Se ativada (5/15/30 min), roda sequencialmente apenas enquanto o popover estiver aberto e `document.visibilityState === "visible"`.
- Falhas não removem a última versão salva.
- Atualização preserva `customName`, condições, overrides e vínculo armazenado no Token.
