# Importação do C.R.I.S.: evidências e limites

## O que foi possível confirmar

1. O site oficial do C.R.I.S. apresenta fichas digitais com dados de agentes, atributos, poderes, equipamentos e imagem do personagem: <https://crisordemparanormal.com/>.
2. Links públicos de fichas compartilhadas aparecem publicamente no formato `https://crisordemparanormal.com/agente/{id}`. Exemplo publicado por um usuário: <https://crisordemparanormal.com/agente/VdnEZBuTtNt1pe6fJSKK>.
3. Um projeto comunitário público de visualização de fichas descreve o Firebase/Firestore como fonte dos dados do CRIS e implementa leitura de documentos na coleção `characters` do projeto `cris-ordem-paranormal`: <https://github.com/LucasPennacchi/visualizador_de_fichas>.
4. O adaptador comunitário citado constrói a rota REST de documentos do Firestore e mapeia campos que incluem `name`, `className`, `nex`, `sheetPictureURL`, `currentPv`, `maxPv`, `currentPe`, `maxPe`, `currentSan`, `maxSan`, `attributes`, `skills`, `inventory`, `rituals` e `powers`.

## O que NÃO foi confirmado

- Não foi encontrada documentação pública oficial do CRIS que garanta esse endpoint como API suportada.
- Não foi possível verificar a resposta live do Firestore a partir deste ambiente de desenvolvimento. O código de terceiros é evidência de implementação comunitária, não prova de que o endpoint ainda esteja acessível, público ou compatível com CORS no momento da execução.
- Não há garantia de que todos os modos de jogo, fichas antigas, fichas com homebrew ou futuras versões usem os mesmos campos.

Por isso o módulo chama esse método de `firestore-best-effort`, mantém o endpoint isolado em `firestore.ts` e não o apresenta como API oficial.

## Fluxo atual

1. `url.ts` aceita apenas `https://crisordemparanormal.com/agente/{id}` (com ou sem `www`). Não aceita endereços de terceiros nem URLs HTTP.
2. `firestore.ts` consulta, sem credenciais, o documento público observado no adaptador comunitário:

   `https://firestore.googleapis.com/v1/projects/cris-ordem-paranormal/databases/(default)/documents/characters/{id}`

3. A resposta do Firestore REST é decodificada recursivamente (`stringValue`, `integerValue`, `doubleValue`, `booleanValue`, `mapValue`, `arrayValue`, etc.).
4. `normalize.ts` mapeia nomes conhecidos e guarda todo campo desconhecido que veio no documento em `additional`.
5. Se a leitura Firestore falhar, `importer.ts` tenta buscar a própria página pública do agente. Quando CORS permite, `htmlParser.ts` busca Open Graph, JSON estruturado, pares label/valor e listas.
6. Se a página exigir login, o navegador bloquear por CORS ou a fonte não devolver dados suficientes, o usuário recebe um erro claro. Não há proxy, serviço intermediário ou acesso com credenciais.

## CORS e acesso privado

CORS é uma decisão do servidor de origem, não algo que a extensão possa legitimamente desativar. Se CRIS ou Firestore não permitirem a origem do navegador, o `fetch` falha e o painel informa isso. O projeto não tenta contornar autenticação, ler cookies, reutilizar sessão, chamar APIs privadas ou fazer proxy para obter conteúdo que o serviço não liberou.

Uma integração mais estável exige que o CRIS publique uma API/documentação ou autorize formalmente um método de integração. Até lá, o adaptador permanece experimental.

## Como testar com uma ficha real

- Use uma ficha pública compartilhada pelo próprio CRIS.
- Abra o console do iframe da extensão e observe erros de rede/CORS.
- Verifique nome, imagem, atributos, barras, listas e `Informações adicionais`.
- Teste uma ficha sem retrato e outra com campos ausentes.
- Teste um link privado: o painel não deve solicitar login e deve manter a versão cacheada, se já houver uma.
