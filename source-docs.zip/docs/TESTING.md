# Testes e checklist manual

## Testes automatizados

```bash
npm install
npm test
npm run build
```

Os testes unitários cobrem:

- Normalização e validação do link público `/agente/{id}`.
- Rejeição de host externo, HTTP e caminhos que não sejam fichas de agente.
- Decodificação dos tipos do Firestore REST.
- Mapeamento de identidade, atributos, vitais e listas.
- Preservação de propriedades desconhecidas em `additional`.
- Ausência de barras vitais que não existem na ficha.

## Checklist manual do Owlbear

- [ ] A extensão aparece na barra superior como **Arquivo de Agentes**.
- [ ] O botão contextual **Abrir ficha do CRIS** aparece quando um Token está selecionado.
- [ ] Token sem vínculo abre o painel e permite escolher a ficha.
- [ ] Token vinculado abre automaticamente a ficha correta.
- [ ] Mover o Token não altera o vínculo.
- [ ] Excluir o Token não apaga a ficha da biblioteca da cena.
- [ ] Recarregar o Owlbear mantém a biblioteca da cena.
- [ ] Outro participante vê os metadados sincronizados pela cena.
- [ ] Jogador não consegue importar, remover, atualizar, vincular ou editar recursos/estado.
- [ ] Atualização preserva overrides de PV/PE/SAN/DT e condição de sessão.
- [ ] CRIS offline/CORS bloqueado não apaga os dados já em cache.
- [ ] Imagem inválida cai para placeholder sem quebrar o layout.
- [ ] Campos desconhecidos aparecem na seção **Informações adicionais**.
- [ ] A interface permanece utilizável em um popover estreito e em viewport móvel.

## Observação

Os testes atuais são unitários e não substituem um teste de integração com uma ficha pública real. A primeira validação live precisa ser executada dentro de um ambiente Owlbear Rodeo com o CRIS acessível ao navegador.
