import OBR from "@owlbear-rodeo/sdk";
import { DEFAULT_SETTINGS, MAX_SYNC_STATE_BYTES, SCENE_STATE_KEY } from "../config";
import type { AppSettings, CharacterSheet, SceneState } from "../types";
import { byteLength } from "../utils/safe";
import { CharacterCache } from "./cache";

function defaultState(): SceneState {
  return {
    schemaVersion: 1,
    characters: {},
    settings: { ...DEFAULT_SETTINGS },
    updatedAt: Date.now(),
  };
}

function sanitizeSettings(value: unknown): AppSettings {
  const raw = value && typeof value === "object" ? (value as Record<string, unknown>) : {};
  const interval = [0, 5, 15, 30].includes(Number(raw.autoRefreshMinutes))
    ? (Number(raw.autoRefreshMinutes) as 0 | 5 | 15 | 30)
    : 0;
  return {
    autoRefreshMinutes: interval,
    showAttributes: raw.showAttributes !== false,
    showInventory: raw.showInventory !== false,
    showAbilities: raw.showAbilities !== false,
    showPhoto: raw.showPhoto !== false,
    compactMode: raw.compactMode === true,
    animations: raw.animations !== false,
  };
}

function sanitizeState(value: unknown): SceneState {
  const raw = value && typeof value === "object" ? (value as Record<string, unknown>) : {};
  const charactersRaw = raw.characters && typeof raw.characters === "object"
    ? (raw.characters as Record<string, unknown>)
    : {};
  const characters: Record<string, CharacterSheet> = {};
  for (const [id, character] of Object.entries(charactersRaw)) {
    if (character && typeof character === "object" && (character as CharacterSheet).id) {
      characters[id] = character as CharacterSheet;
    }
  }
  return {
    schemaVersion: 1,
    characters,
    settings: sanitizeSettings(raw.settings),
    updatedAt: typeof raw.updatedAt === "number" ? raw.updatedAt : Date.now(),
  };
}

export class CharacterRepository {
  private state = defaultState();
  private listeners = new Set<(state: SceneState) => void>();
  private unsubscribeScene?: () => void;
  private saveQueue: Promise<void> = Promise.resolve();
  readonly cache = new CharacterCache();

  get snapshot(): SceneState {
    return this.state;
  }

  subscribe(listener: (state: SceneState) => void): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  private emit(): void {
    for (const listener of this.listeners) listener(this.state);
  }

  async load(): Promise<SceneState> {
    this.cache.setScope(OBR.isAvailable ? OBR.room.id : "local");
    const cached = await this.cache.getAll();
    const localState = defaultState();
    for (const character of cached) localState.characters[character.id] = character;

    if (OBR.isAvailable) {
      try {
        if (await OBR.scene.isReady()) {
          const metadata = await OBR.scene.getMetadata();
          const remoteValue = metadata[SCENE_STATE_KEY];
          if (remoteValue) {
            this.state = sanitizeState(remoteValue);
          } else {
            // O cache local é uma cópia de contingência. Não é promovido automaticamente
            // para a cena, pois isso poderia sobrescrever dados que ainda não chegaram.
            this.state = localState;
          }
          this.bindSceneListener();
        } else {
          this.state = localState;
        }
      } catch {
        this.state = localState;
      }
    } else {
      this.state = localState;
    }
    this.emit();
    return this.state;
  }

  bindSceneListener(): void {
    this.unsubscribeScene?.();
    if (!OBR.isAvailable) return;
    this.unsubscribeScene = OBR.scene.onMetadataChange((metadata) => {
      const incoming = metadata[SCENE_STATE_KEY];
      if (!incoming) return;
      const next = sanitizeState(incoming);
      this.state = next;
      void Promise.all(Object.values(next.characters).map((character) => this.cache.put(character)));
      this.emit();
    });
  }

  async save(next: SceneState): Promise<void> {
    const state = sanitizeState({ ...next, updatedAt: Date.now() });
    this.state = state;
    this.emit();

    await Promise.all(Object.values(state.characters).map((character) => this.cache.put(character)));

    const serialized = JSON.stringify(state);
    if (byteLength(serialized) > MAX_SYNC_STATE_BYTES) {
      throw new Error(
        "A biblioteca excedeu o limite de segurança local para sincronização. Remova campos extras muito grandes ou reduza descrições/imagens incorporadas; imagens devem permanecer como URLs públicas.",
      );
    }

    if (OBR.isAvailable && (await OBR.scene.isReady())) {
      // Serializa gravações locais para reduzir a chance de duas ações do mesmo cliente
      // sobrescreverem uma à outra. O Owlbear propaga o metadata para os participantes.
      this.saveQueue = this.saveQueue.then(async () => {
        await OBR.scene.setMetadata({ [SCENE_STATE_KEY]: state });
      });
      await this.saveQueue;
    }
  }

  async upsert(character: CharacterSheet): Promise<void> {
    const next = { ...this.state, characters: { ...this.state.characters, [character.id]: character } };
    await this.save(next);
  }

  async remove(id: string): Promise<void> {
    const characters = { ...this.state.characters };
    delete characters[id];
    await this.save({ ...this.state, characters });
    await this.cache.delete(id);
  }

  async updateSettings(settings: AppSettings): Promise<void> {
    await this.save({ ...this.state, settings });
  }

  dispose(): void {
    this.unsubscribeScene?.();
    this.unsubscribeScene = undefined;
    this.listeners.clear();
  }
}
