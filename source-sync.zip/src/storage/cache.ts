import type { CharacterSheet } from "../types";

const DB_NAME = "conexao-cris-cache";
const DB_VERSION = 2;
const STORE_NAME = "characters";
const LOCAL_PREFIX = "conexao-cris:character:";

interface CachedCharacter {
  cacheKey: string;
  character: CharacterSheet;
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!("indexedDB" in window)) {
      reject(new Error("IndexedDB indisponível neste navegador."));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (db.objectStoreNames.contains(STORE_NAME)) db.deleteObjectStore(STORE_NAME);
      db.createObjectStore(STORE_NAME, { keyPath: "cacheKey" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Falha ao abrir o cache local."));
  });
}

export class CharacterCache {
  private scope = "local";

  setScope(scope: string): void {
    this.scope = scope || "local";
  }

  private get prefix(): string {
    return `${LOCAL_PREFIX}${this.scope}:`;
  }

  private cacheKey(id: string): string {
    return `${this.scope}::${id}`;
  }

  private async withStore<T>(mode: IDBTransactionMode, action: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, mode);
      const request = action(transaction.objectStore(STORE_NAME));
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("Falha no cache local."));
      transaction.oncomplete = () => db.close();
      transaction.onerror = () => {
        db.close();
        reject(transaction.error ?? new Error("Falha na transação do cache."));
      };
    });
  }

  async getAll(): Promise<CharacterSheet[]> {
    try {
      const records = await this.withStore<CachedCharacter[]>("readonly", (store) => store.getAll());
      return Array.isArray(records)
        ? records.filter((record) => record.cacheKey.startsWith(`${this.scope}::`)).map((record) => record.character)
        : [];
    } catch {
      const items: CharacterSheet[] = [];
      for (let index = 0; index < localStorage.length; index += 1) {
        const key = localStorage.key(index);
        if (!key?.startsWith(this.prefix)) continue;
        try {
          const value = JSON.parse(localStorage.getItem(key) ?? "null") as CharacterSheet;
          if (value?.id) items.push(value);
        } catch {
          // Uma entrada local corrompida não impede a recuperação das outras fichas.
        }
      }
      return items;
    }
  }

  async put(character: CharacterSheet): Promise<void> {
    const record: CachedCharacter = { cacheKey: this.cacheKey(character.id), character };
    try {
      await this.withStore<IDBValidKey>("readwrite", (store) => store.put(record));
    } catch {
      localStorage.setItem(`${this.prefix}${character.id}`, JSON.stringify(character));
    }
  }

  async delete(id: string): Promise<void> {
    try {
      await this.withStore<undefined>("readwrite", (store) => store.delete(this.cacheKey(id)));
    } catch {
      localStorage.removeItem(`${this.prefix}${id}`);
    }
  }
}
