import OBR from "@owlbear-rodeo/sdk";
import { CONTEXT_MENU_ID, CONTEXT_POPOVER_ID, EXTENSION_ID, TOKEN_BINDING_KEY } from "../config";
import type { TokenSummary } from "../types";
import { asRecord } from "../utils/safe";

export async function getCharacterTokens(): Promise<TokenSummary[]> {
  if (!OBR.isAvailable || !(await OBR.scene.isReady())) return [];
  const items = await OBR.scene.items.getItems((item) => item.layer === "CHARACTER");
  return items.map((item) => {
    const binding = asRecord(item.metadata?.[TOKEN_BINDING_KEY]);
    return {
      id: item.id,
      name: item.name?.trim() || "Token sem nome",
      layer: item.layer,
      ...(typeof binding.characterId === "string" ? { characterId: binding.characterId } : {}),
    };
  });
}

export async function linkTokenToCharacter(tokenId: string, characterId: string): Promise<void> {
  if (!OBR.isAvailable || !(await OBR.scene.isReady())) {
    throw new Error("Abra uma cena do Owlbear Rodeo antes de vincular Tokens.");
  }
  const items = await OBR.scene.items.getItems([tokenId]);
  const token = items.find((item) => item.layer === "CHARACTER");
  if (!token) throw new Error("O item selecionado não é um Token da camada de personagens.");

  await OBR.scene.items.updateItems([token], (draftItems) => {
    for (const item of draftItems) {
      item.metadata[TOKEN_BINDING_KEY] = {
        characterId,
        extension: EXTENSION_ID,
        linkedAt: Date.now(),
      };
    }
  });
}

export async function unlinkToken(tokenId: string): Promise<void> {
  if (!OBR.isAvailable || !(await OBR.scene.isReady())) return;
  const items = await OBR.scene.items.getItems([tokenId]);
  if (!items.length) return;
  await OBR.scene.items.updateItems(items, (draftItems) => {
    for (const item of draftItems) delete item.metadata[TOKEN_BINDING_KEY];
  });
}

export async function openTokenPopover(tokenId: string, elementId: string): Promise<void> {
  const target = new URL("./index.html", window.location.href);
  target.searchParams.set("tokenId", tokenId);
  await OBR.popover.open({
    id: CONTEXT_POPOVER_ID,
    url: target.toString(),
    width: 390,
    height: 700,
    anchorElementId: elementId,
  });
}

export async function registerTokenContextMenu(): Promise<void> {
  if (!OBR.isAvailable) return;
  try {
    await OBR.contextMenu.remove(CONTEXT_MENU_ID);
  } catch {
    // A remoção falha normalmente quando esta extensão ainda não registrou o menu.
  }
  await OBR.contextMenu.create({
    id: CONTEXT_MENU_ID,
    icons: [
      {
        icon: "./icon.svg",
        label: "Abrir ficha do CRIS",
        filter: { min: 1, max: 1 },
      },
    ],
    async onClick(context, elementId) {
      const token = context.items.find((item) => item.layer === "CHARACTER");
      if (!token) {
        await OBR.notification.show("Selecione um Token da camada de personagens.", "WARNING");
        return;
      }
      await openTokenPopover(token.id, elementId);
    },
  });
}
