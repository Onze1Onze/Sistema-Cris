import "./ui/styles.css";
import { CharacterApp } from "./ui/app";

const root = document.getElementById("app");
if (!root) throw new Error("Elemento raiz #app não encontrado.");

const app = new CharacterApp(root);
void app.init().catch((error: unknown) => {
  console.error("[Conexão com CRIS] Falha ao iniciar a extensão.", error);
  root.innerHTML = `
    <main class="fatal-error">
      <div class="eyebrow">ERRO DE INICIALIZAÇÃO</div>
      <h1>Arquivo indisponível</h1>
      <p>Não foi possível iniciar a extensão. Recarregue o painel e confira o console do navegador para obter detalhes técnicos.</p>
    </main>
  `;
});

window.addEventListener("beforeunload", () => app.dispose());
